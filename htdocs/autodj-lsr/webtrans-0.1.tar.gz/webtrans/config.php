<?php

//Path to sc_trans_linux (included in the package)
$soundbase = "/var/www/webtrans/sc_trans_040";

//Path to the soundfiles
$soundfiles = "/var/www/webtrans/mp3";

$loginuser = "DJFoobar";
$loginpass = "test";

?>