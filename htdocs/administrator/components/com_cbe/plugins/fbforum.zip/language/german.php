<?php
defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );
//
DEFINE('_UE_FB_TABTITLE','FB-Forum');
DEFINE('_UE_FB_TABDESC','Deine Fireboard-Forumseinstellungen');
DEFINE('_UE_FB_VIEWTYPE_TITLE','Bevorzugte Darstellung');
DEFINE('_UE_FB_VIEWTYPE_FLAT','als Liste');
DEFINE('_UE_FB_VIEWTYPE_THREADED','als Baum');
DEFINE('_UE_FB_ORDERING_TITLE','Bevorzugte Reihenfolge');
DEFINE('_UE_FB_ORDERING_OLDEST','Ältester Beitrag zuerst');
DEFINE('_UE_FB_ORDERING_LATEST','Jüngster Beitrag zuerst');
DEFINE('_UE_FB_SIGNATURE','Signatur');
DEFINE('_UE_FB_POSTSPERPAGE','Einträge pro Seite'); 
DEFINE('_UE_FB_USERTIMEOFFSET','Lokale Zeitdifferenz zur Serverzeit');
// FB Standardsettings
DEFINE('_UE_FB_FORUM_TAB_LABEL','Forum');
DEFINE('_UE_FB_FORUM_TAB_HEADER','Forum Beiträge');
DEFINE('_UE_FB_FORUM_TAB_VIEW_SUBSCRIPTIONS','Anzeige der abonierten Threads');
DEFINE('_UE_FB_FORUM_TAB_VIEW_SETTINGS','Anzeige der Forum Einstellungen');
DEFINE('_UE_FB_THREAD_UNSUBSCRIBE','[abbestellen]');
DEFINE('_UE_FB_THREAD_UNSUBSCRIBE_BACK','[zurück]');
DEFINE('_UE_FB_THREAD_BY','Von');
DEFINE('_UE_FB_NO_SUBSCRIPTIONS','Du hast nichts aboniert.');
DEFINE('_UE_FB_FORUM_SETTINGS_LABEL','Forum Einstellungen');
DEFINE('_UE_FB_FORUM_SETTINGS_DESC','Forum Einstellungen');
DEFINE('_UE_FB_FORUM_SUBSCRIPTIONS_HEADER','Deine abonierten Beiträge');
DEFINE('_UE_FB_FORUM_MODERATOR_HEADER','Du bist als Moderator den folgenden Foren zugeordnet');
DEFINE('_UE_FB_FORUM_SETTINGS_HEADER','Deine Forum Vorgaben');
DEFINE('_UE_FB_FORUM_SETTINGS_VIEW_TYPE','Art der Anzeige:');
DEFINE('_UE_FB_FORUM_SETTINGS_ORDERING','Art der Sortierung:');
DEFINE('_UE_FB_FORUM_SETTINGS_SIGNATURE','Signatur:');
DEFINE('_UE_FB_FORUM_SETTINGS_CHANGE','Du bist dabei Deine Foren Einstellungen zu Ändern');
DEFINE('_UE_FB_FORUM_SETTINGS_SAVE','Speichern');
DEFINE('_UE_FB_FORUM_SETTINGS_BACK','[zurück]');
DEFINE('_UE_FB_FORUM_USER_MODERATOR_NONE','Kein Forum ist Dir zugeordnet');
DEFINE('_UE_FB_FORUM_USER_MODERATOR_ADMIN','Admins sind in allen Foren Moderatoren.');
DEFINE('_UE_FB_FORUM_TAB_VIEW_MODERATION','Zeige Forum Moderator');
DEFINE('_UE_FB_FORUM_DATE','Datum');
DEFINE('_UE_FB_FORUM_SUBJECT','Thema');
DEFINE('_UE_FB_FORUM_CATEGORY','Kategorie');
DEFINE('_UE_FB_FORUM_HITS','Aufrufe');
DEFINE('_UE_FB_FORUM_NO_POSTS','Keine Beiträge');

//Forum Admin Language
DEFINE('_UE_FB_FORUM_TAB_POSTS_PER_PAGE','Forenbeiträge pro Seite');
DEFINE('_UE_FB_FORUM_TAB_POSTS_PER_PAGE_DESC','Wieviele Beiträge sollen pro Seite angezeigt werden?');
?>