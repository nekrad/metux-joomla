<?php
defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );
//
DEFINE('_UE_FB_TABTITLE','FB-Forum');
DEFINE('_UE_FB_TABDESC','Your Fireboard Settings');
DEFINE('_UE_FB_VIEWTYPE_TITLE','Preferred viewtype:');
DEFINE('_UE_FB_VIEWTYPE_FLAT','as list');
DEFINE('_UE_FB_VIEWTYPE_THREADED','as tree');
DEFINE('_UE_FB_ORDERING_TITLE','preferred message ordering:');
DEFINE('_UE_FB_ORDERING_OLDEST','oldes post first');
DEFINE('_UE_FB_ORDERING_LATEST','latest post first');
DEFINE('_UE_FB_SIGNATURE','Signatur');
DEFINE('_UE_FB_POSTSPERPAGE','entries per page'); 
DEFINE('_UE_FB_USERTIMEOFFSET','local timezone difference to server time');
// FB Standardsettings

DEFINE('_UE_FB_FORUM_TAB_LABEL','Forum');
DEFINE('_UE_FB_FORUM_TAB_HEADER','Forum Posts');
DEFINE('_UE_FB_FORUM_TAB_VIEW_SUBSCRIPTIONS','View Forum Subscriptions');
DEFINE('_UE_FB_FORUM_TAB_VIEW_SETTINGS','View Forum Settings');
DEFINE('_UE_FB_THREAD_UNSUBSCRIBE','[unsubscribe]');
DEFINE('_UE_FB_THREAD_UNSUBSCRIBE_BACK','[back]');
DEFINE('_UE_FB_THREAD_BY','By');
DEFINE('_UE_FB_NO_SUBSCRIPTIONS','You do not have any subscriptions.');
DEFINE('_UE_FB_FORUM_SETTINGS_LABEL','Forum Settings');
DEFINE('_UE_FB_FORUM_SETTINGS_DESC','Forum Settings');
DEFINE('_UE_FB_FORUM_SUBSCRIPTIONS_HEADER','Your Forum Subscriptions');
DEFINE('_UE_FB_FORUM_MODERATOR_HEADER','You are assigned as a Moderator for the following forums');
DEFINE('_UE_FB_FORUM_SETTINGS_HEADER','Your Forum Preferences');
DEFINE('_UE_FB_FORUM_SETTINGS_VIEW_TYPE','Preferred viewtype:');
DEFINE('_UE_FB_FORUM_SETTINGS_ORDERING','Preferred message ordering:');
DEFINE('_UE_FB_FORUM_SETTINGS_SIGNATURE','Signature:');
DEFINE('_UE_FB_FORUM_SETTINGS_CHANGE','You are about to update your forum settings');
DEFINE('_UE_FB_FORUM_SETTINGS_SAVE','Save');
DEFINE('_UE_FB_FORUM_SETTINGS_BACK','[back]');
DEFINE('_UE_FB_FORUM_USER_MODERATOR_NONE','No forums found assigned to you');
DEFINE('_UE_FB_FORUM_USER_MODERATOR_ADMIN','Admins are moderator on all forums.');
DEFINE('_UE_FB_FORUM_TAB_VIEW_MODERATION','View Forum Moderator');
DEFINE('_UE_FB_FORUM_DATE','Date');
DEFINE('_UE_FB_FORUM_SUBJECT','Subject');
DEFINE('_UE_FB_FORUM_CATEGORY','Category');
DEFINE('_UE_FB_FORUM_HITS','Hits');
DEFINE('_UE_FB_FORUM_NO_POSTS','No forum posts');

//Forum Admin Language
DEFINE('_UE_FB_FORUM_TAB_POSTS_PER_PAGE','Forum Posts Per Page');
DEFINE('_UE_FB_FORUM_TAB_POSTS_PER_PAGE_DESC','How many forum posts would you like to show on each page?');
?>