<?php
//***********************************************
// CBE-Gallery by Michael Neufing               *
// Copyright (c) 2007 Michael Neufing           *
// http://www.k-b-j.de.vu                       *
// Released under the GNU/GPL License           *
// Version 1.0 File date: 11-03-2007            *
//***********************************************

defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );

include ("german.php");
?>